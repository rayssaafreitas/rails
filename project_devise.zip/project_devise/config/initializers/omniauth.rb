 Rails.application.config.middleware.use OmniAuth::Builder do
   provider :facebook, ENV['408568623212636'], ENV['850928c214ed5c54499846d888146e43'],
            :scope => 'email,user_birthday,read_stream', :display => 'popup'
 end